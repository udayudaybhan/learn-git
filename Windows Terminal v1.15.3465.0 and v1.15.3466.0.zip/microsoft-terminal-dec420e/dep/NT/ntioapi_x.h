/*++
Copyright (c) Microsoft Corporation.
Licensed under the MIT license.
--*/

#pragma once

#define FILE_SYNCHRONOUS_IO_NONALERT            0x00000020
