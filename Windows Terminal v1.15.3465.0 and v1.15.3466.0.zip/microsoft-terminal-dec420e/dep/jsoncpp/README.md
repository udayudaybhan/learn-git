# jsoncpp

[Amalgamated](https://github.com/open-source-parsers/jsoncpp/wiki/Amalgamated)
from source commit
[5defb4e](https://github.com/open-source-parsers/jsoncpp/commit/5defb4ed1a4293b8e2bf641e16b156fb9de498cc),
release 1.9.5.

> Generating amalgamated source and header JsonCpp is provided with a script to
> generate a single header and a single source file to ease inclusion into an
> existing project. The amalgamated source can be generated at any time by
> running the following command from the top-directory (this requires Python
> 3.4+):
>
> ```
> python amalgamate.py
> ```
